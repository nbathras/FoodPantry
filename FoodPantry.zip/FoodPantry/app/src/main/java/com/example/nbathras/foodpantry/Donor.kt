package com.example.nbathras.foodpantry

data class Donor (
    val userId: String    = "",
    val donorId: String   = "",
    val donorType: String = "",
    val donorName: String = "",
    val donorPhone: String = ""
)